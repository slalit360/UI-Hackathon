package in.geektrust.lengaburu.bean;

public class LengaburuOrbit {
	
	String weather;
	int traffic_speed;
	Routes route;
	Vehicles bike, car, tuktuk;
	
	public LengaburuOrbit(String weather, int traffic_speed, Routes route) {
		super();
		this.weather 		= weather;
		this.traffic_speed 	= traffic_speed;
		this.route 			= route;					//new Routes(18, 20);
		this.car = new Vehicles("Car", 20, 3); 			// name, speed, potholes time
		
		if (this.weather.equals("rainy")){	
			this.tuktuk = new Vehicles("Tuktuk", 12, 1);
		}
		else if (this.weather.equals("windy")){
			this.bike = new Vehicles("Bike", 10, 2);
		}
		else if (this.weather.equals("sunny")){
			this.tuktuk = new Vehicles("Tuktuk", 12, 1);
			this.bike = new Vehicles("Bike", 10, 2);
		}
		else {
			System.out.println("Invalid Weather !");
			System.exit(0);
		}
		
	}
	
	public int getMaxSpeed( int vehicalSpeed ) {
		
		return this.traffic_speed > vehicalSpeed ? vehicalSpeed : this.traffic_speed;
	}

	public int getTimeMinutes( int maxSpeed, int timeToCrossCarters) 
	{
		return (int) ((this.route.getTotalDist() * 60) / maxSpeed ) + (this.route.getNoPotholes() * timeToCrossCarters);
	}
	
	public String[] getTimeAndVehicle() 
	{
		//System.out.println("route : " + this.route.getRouteName());
		
		if (this.weather.equals("rainy")) 
		{
			this.route.setNoPotholes((int) (this.route.getNoPotholes() + (this.route.getNoPotholes() * 20 / 100)));
			
			int carTimeMinutes = this.getTimeMinutes( this.getMaxSpeed(this.car.getVehicleSpeed()), 
													  this.car.getVehiclePotholeTime() );
			
			int tuktukTimeMinutes = this.getTimeMinutes( this.getMaxSpeed(this.tuktuk.getVehicleSpeed()), 
														 this.tuktuk.getVehiclePotholeTime() );
			
			return tuktukTimeMinutes > carTimeMinutes
					? new String[] { this.route.getRouteName() , this.car.getVehicleName(), Integer.toString(carTimeMinutes) }
					: new String[] { this.route.getRouteName(), this.tuktuk.getVehicleName(), Integer.toString(tuktukTimeMinutes) };
		}
		else if (this.weather.equals("windy")) 
		{	
			int carTimeMinutes = this.getTimeMinutes( this.getMaxSpeed(this.car.getVehicleSpeed()),
													  this.car.getVehiclePotholeTime() );
			
			int bikeTimeMinutes = this.getTimeMinutes( this.getMaxSpeed(this.bike.getVehicleSpeed()), 
													   this.bike.getVehiclePotholeTime() );
			
			return bikeTimeMinutes > carTimeMinutes
					? new String[] { this.route.getRouteName(), this.car.getVehicleName(), Integer.toString(carTimeMinutes) }
					: new String[] { this.route.getRouteName(), this.bike.getVehicleName(), Integer.toString(bikeTimeMinutes) };
		}
		else if (this.weather.equals("sunny"))
		{
			this.route.setNoPotholes((int) (this.route.getNoPotholes() + (this.route.getNoPotholes() * -10 / 100)));
			
			
			int carTimeMinutes = this.getTimeMinutes(this.getMaxSpeed(this.car.getVehicleSpeed()), 
													 this.car.getVehiclePotholeTime());

			int bikeTimeMinutes = this.getTimeMinutes(this.getMaxSpeed(this.bike.getVehicleSpeed()), 
					                                  this.bike.getVehiclePotholeTime());
			
			int tuktukTimeMinutes = this.getTimeMinutes(this.getMaxSpeed(this.tuktuk.getVehicleSpeed()), this.tuktuk.getVehiclePotholeTime());
			
			if (bikeTimeMinutes < carTimeMinutes && bikeTimeMinutes < tuktukTimeMinutes){
				return new String[] { this.route.getRouteName(), this.bike.getVehicleName(), Integer.toString(bikeTimeMinutes) };
			} 
			else if (carTimeMinutes < tuktukTimeMinutes && carTimeMinutes < bikeTimeMinutes ){
				return new String[] { this.route.getRouteName(), this.car.getVehicleName(), Integer.toString(carTimeMinutes) };
			} 
			else {
				return new String[] { this.route.getRouteName(), this.tuktuk.getVehicleName(), Integer.toString(tuktukTimeMinutes) };
			}
		
		}
		else { System.out.println("Not valid Weather !"); }
		
		return new String[] {};
	}

	@Override
	public String toString() {
		return "LengaburuOrbit [ " + this.route
				+ ", " + this.bike + ", " + this.car + ", " + this.tuktuk + "]";
	}

	
}
