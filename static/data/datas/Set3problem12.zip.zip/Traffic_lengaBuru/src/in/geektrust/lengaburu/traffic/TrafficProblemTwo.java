package in.geektrust.lengaburu.traffic;

import java.util.Scanner;

import in.geektrust.lengaburu.bean.LengaburuOrbit;
import in.geektrust.lengaburu.bean.Routes;

public class TrafficProblemTwo {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the weather in Lengaburu : ");
		String weather = scanner.next().toLowerCase().strip();
		
		System.out.println("Enter the Speed via Orbit 1 : ");
		int orbitOneSpeed = scanner.nextInt();
				
		System.out.println("Enter the Speed via Orbit 2 : ");
		int orbitTwoSpeed = scanner.nextInt();
		
		System.out.println("Enter the Speed via Orbit 3 : ");
		int orbitThreeSpeed = scanner.nextInt();
				
		System.out.println("Enter the Speed via Orbit 4 : ");
		int orbitFourSpeed = scanner.nextInt();
		
	
		LengaburuOrbit orbitOne = new LengaburuOrbit(weather, orbitOneSpeed, new Routes("Orbit 1", 18, 20));
		
		LengaburuOrbit orbitTwo = new LengaburuOrbit(weather, orbitTwoSpeed, new Routes("Orbit 2", 20, 10));
		
		LengaburuOrbit orbitThree = new LengaburuOrbit(weather, orbitThreeSpeed, new Routes("Orbit 3", 30, 15));
		
		LengaburuOrbit orbitFour = new LengaburuOrbit(weather, orbitFourSpeed, new Routes("Orbit 4", 15, 18));
		
		String [] orbitOneData = orbitOne.getTimeAndVehicle();
		String [] orbitTwoData = orbitTwo.getTimeAndVehicle();
		String [] orbitThreeData = orbitThree.getTimeAndVehicle();
		String [] orbitFourData = orbitFour.getTimeAndVehicle();

		if(Integer.parseInt(orbitOneData[2])< Integer.parseInt(orbitTwoData[2]) && Integer.parseInt(orbitOneData[2])< Integer.parseInt(orbitThreeData[2]))
		{	
			if(orbitOneData[1] == orbitFourData[1]) {
				System.out.println("Vehicle "+ orbitOneData[1] +" to Hallitharam via "+orbitOneData[0]+" and RK Puram via "+ orbitFourData[0]);
			}
		}
		else if( Integer.parseInt(orbitTwoData[2])< Integer.parseInt(orbitOneData[2]) && Integer.parseInt(orbitTwoData[2])< Integer.parseInt(orbitThreeData[2]))
		{	
			if( orbitTwoData[1] == orbitFourData[1]) {
				System.out.println("Vehicle "+ orbitTwoData[1] +" to Hallitharam via "+orbitTwoData[0]+" and RK Puram via "+ orbitFourData[0]);
			}
		}
		else {	
			if(orbitThreeData[1] == orbitFourData[1]) {
				System.out.println("Vehicle "+ orbitThreeData[1] +" to RK Puram via "+orbitThreeData[0]+" and Hallitharam via "+ orbitFourData[0]);
			}
		}
	}

}
