package in.geektrust.lengaburu.bean;

public class Vehicles {

	String vehicleName;
	int vehicleSpeed;
	int vehiclePotholeTime;
	//private String[] vehicleWeather = new String[] { "Sunny", "Rainy", "Windy" };
	
	public Vehicles(String vehicleName, int vehicleSpeed, int vehiclePotholeTime) {
		super();
		this.vehicleName = vehicleName;
		this.vehicleSpeed = vehicleSpeed;
		this.vehiclePotholeTime = vehiclePotholeTime;
	}

	public String getVehicleName() {
		return vehicleName;
	}

	public void setVehicleName(String vehicleName) {
		this.vehicleName = vehicleName;
	}

	public int getVehicleSpeed() {
		return vehicleSpeed;
	}

	public void setVehicleSpeed(int vehicleSpeed) {
		this.vehicleSpeed = vehicleSpeed;
	}

	public int getVehiclePotholeTime() {
		return vehiclePotholeTime;
	}

	public void setVehiclePotholeTime(int vehiclePotholeTime) {
		this.vehiclePotholeTime = vehiclePotholeTime;
	}

	@Override
	public String toString() {
		return "{ vehicleName : " + this.vehicleName + ", vehicleSpeed : " + this.vehicleSpeed + ", vehiclePotholeTime : "
				+ this.vehiclePotholeTime + "}";
	}
	
}