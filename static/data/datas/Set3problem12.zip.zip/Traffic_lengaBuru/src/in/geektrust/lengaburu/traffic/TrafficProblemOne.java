package in.geektrust.lengaburu.traffic;

import java.util.Scanner;

import in.geektrust.lengaburu.bean.LengaburuOrbit;
import in.geektrust.lengaburu.bean.Routes;

public class TrafficProblemOne {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter the weather in Lengaburu : ");
		String weather = scanner.next().toLowerCase().strip();
		
		System.out.println("Enter the Speed via Orbit 1 : ");
		int orbitOneSpeed = scanner.nextInt();
				
		System.out.println("Enter the Speed via Orbit 2 : ");
		int orbitTwoSpeed = scanner.nextInt();
		
	
		LengaburuOrbit mangalrokaOrbit = new LengaburuOrbit(weather, orbitOneSpeed, new Routes("Orbit 1", 18, 20));
		
		LengaburuOrbit dellanburuOrbit = new LengaburuOrbit(weather, orbitTwoSpeed, new Routes("Orbit 2", 20, 10));
		
		String [] mdata = mangalrokaOrbit.getTimeAndVehicle();
		String [] ddata = dellanburuOrbit.getTimeAndVehicle();

		if(Integer.parseInt(mdata[2])< Integer.parseInt(ddata[2]))
		{
			System.out.println("Vehicle "+ mdata[1] +" on "+mdata[0]+" route.");
		}
		else 
		{
			System.out.println("Vehicle "+ ddata[1] +" on "+ddata[0]+" route.");
		}


	}

}
