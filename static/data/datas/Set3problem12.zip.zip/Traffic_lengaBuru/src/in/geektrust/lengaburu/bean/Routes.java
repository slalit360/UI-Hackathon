package in.geektrust.lengaburu.bean;

public class Routes {
	
	 String routeName;
	 int totalDist;
	 int noPotholes;
	
	public Routes(String routeName, int totalDist, int noPotholes) {
		super();
		this.routeName = routeName;
		this.totalDist = totalDist;
		this.noPotholes = noPotholes;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	public int getTotalDist() {
		return totalDist;
	}
	
	public void setTotalDist(int totalDist) {
		this.totalDist = totalDist;
	}
	
	public int getNoPotholes() {
		return noPotholes;
	}
	
	public void setNoPotholes(int noPotholes) {
		this.noPotholes = noPotholes;
	}

	@Override
	public String toString() {
		return "{ routeName : " + this.getRouteName() + ", totalDist : " + this.getTotalDist() + ", noPotholes : " + this.getNoPotholes() + "}";
	}

}